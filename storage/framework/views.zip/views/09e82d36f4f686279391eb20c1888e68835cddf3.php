<?php if(isset($autoAdvertising) and !empty($autoAdvertising)): ?>
	<div class="row d-flex justify-content-center m-0 p-0">
		<div class="col-12 text-center m-0 p-0">
			<?php echo $autoAdvertising->tracking_code_large; ?>

		</div>
	</div>
<?php endif; ?>
<?php /**PATH /var/www/html/virtualworkers.app/resources/views/layouts/inc/advertising/auto.blade.php ENDPATH**/ ?>