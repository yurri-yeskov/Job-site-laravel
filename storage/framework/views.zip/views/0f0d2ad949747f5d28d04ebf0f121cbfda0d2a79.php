<div class="modal fade" id="socialFillSignup" tabindex="-1" role="dialog">
	<div class="modal-dialog  modal-sm">
		<div class="modal-content">
			
			<div class="modal-header">
				<!-- <h4 class="modal-title"><i class="icon-login fa"></i> <?php echo e(t('log_in')); ?> </h4> -->
				
				<button type="button" class="close" data-dismiss="modal">
					<span aria-hidden="true">&times;</span>
					<span class="sr-only"><?php echo e(t('Close')); ?></span>
				</button>
			</div>
			
			<div class="signup-wrap">
				
				<input type="hidden" name="language_code" value="<?php echo e(config('app.locale')); ?>">
				<div class="modal-body">
					<div class="signup-heading">
						<img src="<?php echo e(asset('/images/site_logo.png')); ?>" title="" />
					</div>
					<!-- screen two -->
					<div class="social-signup-two">
						<div class="signup-heading"><?php echo e(t('sign_up')); ?></div>
						<form role="form" method="POST" action="/auth/social/signup">
							<?php echo csrf_field(); ?>

							<?php 
								$socialEmail = session()->has('email') ?  session()->get('email') : '';
							?>
							<input type="hidden" name="email" value="<?php echo e($socialEmail); ?>" />
							<!-- firstname -->
							<div class="form-group row required">
								<div class="col-md-12">
									<div class="input-group show-pwd-group">
										<?php 
											$socialFirstName = session()->has('first_name') ?  session()->get('first_name') : '';
										?>
										<input type="text" class="form-control" placeholder="<?php echo e(t('first_name')); ?>" autocomplete="off" value="<?php echo e($socialFirstName); ?>" disabled="disabled">
										<span class="icon-append show-pwd">
											<button type="button" class="first_name_w">
												<img src="<?php echo e(asset('/images/name_icon.png')); ?>" class="input-img" />
											</button>
										</span>
									</div>
								</div>
							</div>
							<!-- lastname -->
							<div class="form-group row required">
								<div class="col-md-12">
									<div class="input-group show-pwd-group">
										<?php 
											$socialLastName = session()->has('first_name') ?  session()->get('first_name') : '';
										?>
										<input type="text" class="form-control" placeholder="<?php echo e(t('last_name')); ?>" autocomplete="off" value="<?php echo e($socialLastName); ?>" disabled="disabled">
										<span class="icon-append show-pwd">
											<button type="button" class="last_name_w">
												<img src="<?php echo e(asset('/images/name_icon.png')); ?>" class="input-img" />
											</button>
										</span>
									</div>
								</div>
							</div>
							<!-- country -->
							<div class="form-group row required">
								<div class="col-md-12">
									<div class="input-group show-pwd-group">
										<input  name="country" type="text" class="form-control" placeholder="Philippines" autocomplete="off" value="Philippines" disabled="disabled">
										<span class="icon-append show-pwd">
											<button type="button" class="country_w">
												<img src="<?php echo e(asset('/images/country_icon.png')); ?>" class="input-img" />
											</button>
										</span>
									</div>
								</div>
							</div>
							<!-- country -->
							<div class="form-group row required">
								<div class="col-md-12">
									<div class="input-group show-pwd-group">
										<div class="input-group">
											<select id="city_w" name="city" class="form-control" >
												<?php $cities = \App\Helpers\PhilippineCities::getCities(); ?>
												<?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option value="<?php echo e($city->id); ?>"> <?php echo e($city->city); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												
											</select>
											<span class="icon-append show-pwd">
												<button type="button" class="city_w">
													<img src="<?php echo e(asset('/images/city_icon.png')); ?>" class="input-img-city" />
												</button>
											</span>
										</div>
									</div>
								</div>
							</div>

							<div class="alert alert-danger print-error-msg-two" style="display:none">
						        <ul></ul>
						    </div>

							<!-- Button  -->
							<div class="form-group row mt-5 mb-5">
								<div class="col-md-12">
									<button type="submit" id="signupBtnWSecondSocial" class="btn btn-custom btn-lg "> <?php echo e(t('submit')); ?> </button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php /**PATH /var/www/html/virtualworkers.app/resources/views/layouts/inc/modal/social-signup.blade.php ENDPATH**/ ?>