<?php if($xPanel->hasAccess('create')): ?>
	<a href="<?php echo e(url($xPanel->route.'/create')); ?>" class="btn btn-primary shadow ladda-button" data-style="zoom-in">
		<span class="ladda-label">
            <i class="fas fa-plus"></i> <?php echo e(trans('admin.add')); ?> <?php echo $xPanel->entityName; ?>

        </span>
    </a>
<?php endif; ?><?php /**PATH /var/www/html/virtualworkers.app/resources/views/vendor/admin/panel/buttons/create.blade.php ENDPATH**/ ?>