
<td data-order="<?php echo e($entry->{$column['name']}); ?>">
	<?php
	try {
		$dateColumnValue = (new \Illuminate\Support\Carbon($entry->{$column['name']}))->timezone(\App\Helpers\Date::getAppTimeZone());
	} catch (\Exception $e) {
		$dateColumnValue = new \Illuminate\Support\Carbon($entry->{$column['name']});
	}
	?>
	<?php echo e(\App\Helpers\Date::format($dateColumnValue, 'datetime')); ?>

</td><?php /**PATH /var/www/html/virtualworkers.app/resources/views/vendor/admin/panel/columns/datetime.blade.php ENDPATH**/ ?>