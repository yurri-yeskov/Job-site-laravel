<?php if(!(isset($paddingTopExists) and $paddingTopExists)): ?>
	<div class="h-spacer"></div>
<?php endif; ?><?php /**PATH /var/www/html/virtualworkers.app/resources/views/common/spacer.blade.php ENDPATH**/ ?>