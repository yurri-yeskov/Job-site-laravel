<?php $__env->startSection('search'); ?>
	##parent-placeholder-3559d7accf00360971961ca18989adc0614089c0##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="main-containers" id="homepage">
	
		<?php if(session()->has('flash_notification')): ?>
			<?php echo $__env->first([config('larapen.core.customizedViewPath') . 'common.spacer', 'common.spacer'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php $paddingTopExists = true; ?>
			<div class="container">
				<div class="row">
					<div class="col-xl-12">
						<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
				</div>
			</div>
		<?php endif; ?>
		
		<div class="main">
      <div class="banner" style="background-image: url('https://production.virtualworkers.ph/staging/public/assets/image/AdobeStock_172331101 (2) 1.png'); background-size: cover;">
          <div class="container">
              <div class="row">
                  <div class="col-md-1"></div>
              <div class="col-md-5">
                  <button class="banner-btn"><svg class="svg-inline--fa fa-user-tie fa-w-14" aria-hidden="true" focusable="false" data-prefix="fa" data-icon="user-tie" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg=""><path fill="currentColor" d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm95.8 32.6L272 480l-32-136 32-56h-96l32 56-32 136-47.8-191.4C56.9 292 0 350.3 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-72.1-56.9-130.4-128.2-133.8z"></path></svg><!-- <i class="fa fa-user-tie"></i> --> <span> I AM LOOKING FOR GREAT OFFSHORE STAFF</span></button>
              </div>
              <div class="col-md-5">
                  <button type="button" class="banner-btn" data-toggle="modal" data-target="#quickSignup"><svg class="svg-inline--fa fa-money-bill-wave fa-w-20" aria-hidden="true" focusable="false" data-prefix="fa" data-icon="money-bill-wave" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512" data-fa-i2svg=""><path fill="currentColor" d="M621.16 54.46C582.37 38.19 543.55 32 504.75 32c-123.17-.01-246.33 62.34-369.5 62.34-30.89 0-61.76-3.92-92.65-13.72-3.47-1.1-6.95-1.62-10.35-1.62C15.04 79 0 92.32 0 110.81v317.26c0 12.63 7.23 24.6 18.84 29.46C57.63 473.81 96.45 480 135.25 480c123.17 0 246.34-62.35 369.51-62.35 30.89 0 61.76 3.92 92.65 13.72 3.47 1.1 6.95 1.62 10.35 1.62 17.21 0 32.25-13.32 32.25-31.81V83.93c-.01-12.64-7.24-24.6-18.85-29.47zM48 132.22c20.12 5.04 41.12 7.57 62.72 8.93C104.84 170.54 79 192.69 48 192.69v-60.47zm0 285v-47.78c34.37 0 62.18 27.27 63.71 61.4-22.53-1.81-43.59-6.31-63.71-13.62zM320 352c-44.19 0-80-42.99-80-96 0-53.02 35.82-96 80-96s80 42.98 80 96c0 53.03-35.83 96-80 96zm272 27.78c-17.52-4.39-35.71-6.85-54.32-8.44 5.87-26.08 27.5-45.88 54.32-49.28v57.72zm0-236.11c-30.89-3.91-54.86-29.7-55.81-61.55 19.54 2.17 38.09 6.23 55.81 12.66v48.89z"></path></svg><!-- <i class="fa fa-money-bill-wave"></i> --> <span>I AM LOOKING FOR GREAT JOB</span></button>
              </div>
              <div class="col-md-1"></div>
              </div>
          </div>
      </div>
      <div class="popular-categories">
        <h1>Popular Categories</h1>
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-6 col-md-3">
              <div class="item">
                <h3>Design, Art & Multimedia</h3>
                <p>(22 open positions)</p>
              </div>
            </div>
            <div class="col-sm-6 col-md-3">
              <div class="item">
                <h3>Education Training</h3>
                <p>(6 open positions)</p>
              </div>
            </div>
            <div class="col-sm-6 col-md-3">
              <div class="item">
                <h3>Accounting / Finance</h3>
                <p>(3 open positions)</p>
              </div>
            </div>
            <div class="col-sm-6 col-md-3">
              <div class="item">
                <h3>Human Resource</h3>
                <p>(3 open positions)</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="banner-secondary" style="background-image:url('<?php echo e(url()->asset('public/images/newdesign/AdobeStock_345291349 1@3x.png') . getPictureVersion()); ?>')">
        <div class="container">
          <div class="row">
            <div class="col-sm-12 col-md-6">
              <h1>
                Helping the Filipino Community Find Safe, Reliable Work from Home
                                                            Positions
              </h1>
            </div>
            <div class="col-sm-12 col-md-6">
              <p>
                We live in an uncertain time – one that is changing by the day and
                                                            requiring more individuals to think outside the box when seeking
                                                            employment. "Business as usual" doesn't hold the same meaning as
                                                            it did a year ago, requiring companies to outsource more positions
                                                            than ever before.<br/>So, how do you find the right job or fill a
                                                            position requiring outsourcing? By seeking out the help of a
                                                            virtual assistant agency.
              </p>
            </div>
          </div>
        </div>
      </div>
      <div class="funnel">
        <h1>funnel and paid traffic…</h1>
        <button>Without actually building a funnel or running ads!</button>
      </div>
      <div class="recent-jobs">
        <h1>Recent Jobs</h1>
        <p>Leading Employers already using job and talent.</p>
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-12 col-md-4">
              <div class="item">
                <img src="<?php echo e(url()->asset('public/images/newdesign/icon-tv.png') . getPictureVersion()); ?>" class="mx-auto" alt="Icon"/>
                <h3>Networking Engineer</h3>
                <p>GUXOFT</p>
                <div class="action">
                  <span>Ukraine</span>
                  <button type="button" class="border-green color-green">Full Time</button>
                </div>
              </div>
            </div>
            <div class="col-sm-12 col-md-4">
              <div class="item">
                <img src="<?php echo e(url()->asset('public/images/newdesign/icon-line.png') . getPictureVersion()); ?>" class="mx-auto" alt="Icon"/>
                <h3>Front End Developer</h3>
                <p>Norson</p>
                <div class="action">
                  <span>Ukraine</span>
                  <button type="button" class="border-red color-red">Temporary</button>
                </div>
              </div>
            </div>
            <div class="col-sm-12 col-md-4">
              <div class="item">
                <img src="<?php echo e(url()->asset('public/images/newdesign/icon-cube.png') . getPictureVersion()); ?>" class="mx-auto" alt="Icon"/>
                <h3 class="color-dark">Senior UX Designer</h3>
                <p>NetSuite</p>
                <div class="action">
                  <span>Ukraine</span>
                  <button type="button" class="border-red color-red">Temporary</button>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-12 col-md-4">
              <div class="item">
                <img src="<?php echo e(url()->asset('public/images/newdesign/icon-flusk.png') . getPictureVersion()); ?>" class="mx-auto" alt="Icon"/>
                <h3>JEB Product Sales Specialist, Russia & CIS</h3>
                <p>General Electric</p>
                <div class="action">
                  <span>Ukraine</span>
                  <button type="button" class="border-blue color-blue">Part Time</button>
                </div>
              </div>
            </div>
            <div class="col-sm-12 col-md-4">
              <div class="item">
                <img src="<?php echo e(url()->asset('public/images/newdesign/icon-circle.png') . getPictureVersion()); ?>" class="mx-auto" alt="Icon"/>
                <h3>Technical Support Specialist</h3>
                <p>Man Power Group</p>
                <div class="action">
                  <span>Ukraine</span>
                  <button type="button" class="border-blue color-blue">Freelance</button>
                </div>
              </div>
            </div>
            <div class="col-sm-12 col-md-4">
              <div class="item">
                <img src="<?php echo e(url()->asset('public/images/newdesign/icon-tv.png') . getPictureVersion()); ?>" class="mx-auto" alt="Icon"/>
                <h3 class="color-dark">Networking Engineer</h3>
                <p>GUXOFT</p>
                <div class="action">
                  <span>Ukraine</span>
                  <button type="button" class="border-red color-red">Full Time</button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <button type="button" class="border-pink color-pink">Load more listings</button>
      </div>
      <div class="assistant-agency">
        <h2>More Than Your Average Virtual Assistant Agency</h2>
        <img src="<?php echo e(url()->asset('public/images/newdesign/New-Logo-Main-Index-(Updated) 1.png') . getPictureVersion()); ?>" alt=""/>
        <div class="container">
          <div class="row">
            <div class="col-sm-12 col-md-6">
              <p>
                Whether you are looking for a virtual assistant or a skilled
                                                            writer – we've got solutions across all industries.<br/><br/>
                With virtual work becoming the new norm, job recruiters must have
                                                            a place to find qualified candidates, whether it be someone to
                                                            handle back-office work or a new web designer for your website.
                <br/><br/>
                Those searching for work also need a place to find jobs. There are
                                                            many benefits of being a virtual assistant or seeking other remote
                                                            employment, such as setting your hours and working from the
                                                            comfort of your home.
              </p>
            </div>
            <div class="col-sm-12 col-md-6">
              <p>
                However, it's not as simple as going online, filling out an
                                                            application, and waiting for a phone call. Now, you must sift
                                                            through the overwhelming number of online listings, trying to
                                                            figure out what is a legitimate position and what is not.<br/><br/><u>The key for both recruiters and job seekers: knowing where to
                                                                    go.</u><br/><br/>Recruiters need to know they can sift through
                                                                  committed individuals with the necessary skills to get the job
                                                                  done.<br/><br/>Job seekers need to know that they can check the
                                                                  job board with confidence that the postings are real jobs that can
                                                                  provide reliable work.
              </p>
            </div>
          </div>
        </div>
        <h1>Single Payment of $27</h1>
        <button>Ridiculous? Definitely... Short-sighted? We'll see.</button>
      </div>
      <div class="benefit">
        <h1>Who Can Benefit from Our Services?</h1>
        <p>
          Virtual Workers' mission is to help the Filipino community find safe and
                                    reliable work from home positions and help recruiters find serious
                                    candidates that are ready to work. That said, both recruiters and job
                                    seekers could benefit from our services.
        </p>
      </div>
      <div class="recent-candidates">
        <h1>Recent Candaites</h1>
        <p>Leading Employers already using job and talent.</p>
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-12 col-md-4">
              <div class="item">
                <img src="<?php echo e(url()->asset('public/images/newdesign/avatar.png') . getPictureVersion()); ?>" class="mx-auto" alt="Icon"/>
                <h3>Networking Engineer</h3>
                <p>GUXOFT</p>
                <div class="action">
                  <span>Ukraine</span>
                  <button type="button" class="border-green color-green">Full Time</button>
                </div>
              </div>
            </div>
            <div class="col-sm-12 col-md-4">
              <div class="item">
                <img src="<?php echo e(url()->asset('public/images/newdesign/avatar.png') . getPictureVersion()); ?>" class="mx-auto" alt="Icon"/>
                <h3>Front End Developer</h3>
                <p>Norson</p>
                <div class="action">
                  <span>Ukraine</span>
                  <button type="button" class="border-red color-red">Temporary</button>
                </div>
              </div>
            </div>
            <div class="col-sm-12 col-md-4">
              <div class="item">
                <img src="<?php echo e(url()->asset('public/images/newdesign/avatar.png') . getPictureVersion()); ?>" class="mx-auto" alt="Icon"/>
                <h3 class="color-dark">Senior UX Designer</h3>
                <p>NetSuite</p>
                <div class="action">
                  <span>Ukraine</span>
                  <button type="button" class="border-red color-red">Temporary</button>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-12 col-md-4">
              <div class="item">
                <img src="<?php echo e(url()->asset('public/images/newdesign/avatar.png') . getPictureVersion()); ?>" class="mx-auto" alt="Icon"/>
                <h3>JEB Product Sales Specialist, Russia & CIS</h3>
                <p>General Electric</p>
                <div class="action">
                  <span>Ukraine</span>
                  <button type="button" class="border-blue color-blue">Part Time</button>
                </div>
              </div>
            </div>
            <div class="col-sm-12 col-md-4">
              <div class="item">
                <img src="<?php echo e(url()->asset('public/images/newdesign/avatar.png') . getPictureVersion()); ?>" class="mx-auto" alt="Icon"/>
                <h3>Technical Support Specialist</h3>
                <p>Man Power Group</p>
                <div class="action">
                  <span>Ukraine</span>
                  <button type="button" class="border-blue color-blue">Freelance</button>
                </div>
              </div>
            </div>
            <div class="col-sm-12 col-md-4">
              <div class="item">
                <img src="<?php echo e(url()->asset('public/images/newdesign/avatar.png') . getPictureVersion()); ?>" class="mx-auto" alt="Icon"/>
                <h3 class="color-dark">Networking Engineer</h3>
                <p>GUXOFT</p>
                <div class="action">
                  <span>Ukraine</span>
                  <button type="button" class="border-red color-red">Full Time</button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <button type="button" class="border-pink color-pink">Load more listings</button>
      </div>
      <div class="seekers-recruiters">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-12 col-md-6">
              <img src="<?php echo e(url()->asset('public/images/newdesign/seekers.png') . getPictureVersion()); ?>" alt=""/>
              <div class="seekers">
                <h1>Job Seekers!</h1>
                <p>
                  Looking for a new opportunity to work from home? Whatever the
                                                                    situation, Virtual Workers is the best place to get started. Our
                                                                    job boards include open positions across all industries,
                                                                    ensuring that you'll find the best position for your skills.
                                                                    Need help building your curriculum vitae? We offer free CV
                                                                    templates to help you build a resume that will allow you to
                                                                    stand out.
                </p>
                <button>Job Seekers Start Here</button>
              </div>
            </div>
            <div class="col-sm-12 col-md-6">
              <img src="<?php echo e(url()->asset('public/images/newdesign/recruiters.png') . getPictureVersion()); ?>" alt=""/>
              <div class="recruiters">
                <h1>Recruiters!</h1>
                <p>
                  As a brand recruiter, you already know the many benefits of
                                                                    outsourcing a virtual assistant for data entry or
                                                                    telecommunication tasks. More jobs have become remote, meaning
                                                                    that your brand can reach out and select the most qualified
                                                                    candidates, no matter where they are. By posting your open jobs
                                                                    on Virtual Workers, you are sure to find the most qualified
                                                                    candidates who are eager to get to work.
                </p>
                <button>Recruiters Start Here</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="works-how">
        <h1>How It Works</h1>
        <p>
          At Virtual Workers, we provide a safe space for both recruiters and job
                                    seekers. We understand that navigating the job market is difficult,
                                    which is why we are building an all-inclusive community that benefits
                                    everyone.
        </p>
        <img src="<?php echo e(url()->asset('public/images/newdesign/New-Logo-Main-Index-(Updated) 1.png') . getPictureVersion()); ?>" alt="Logo"/>
        <div class="container">
          <div class="row">
            <div class="col-sm-12 col-md-6">
              <div class="job-info">
                <img src="<?php echo e(url()->asset('public/images/newdesign/Rectangle.png') . getPictureVersion()); ?>" class="mx-auto" alt="Avatar"/>
                <p>
                  Recruiters register their account and then post their open
                                                                    positions on our job board and list all the necessary
                                                                    information, such as:
                </p>
                <ul>
                  <li>Job Title</li>
                  <li>Description of the Position</li>
                  <li>Experience/Skills Required</li>
                  <li>Pay/Salary</li>
                  <li>Contact Information and more</li>
                </ul>
              </div>
            </div>
            <div class="col-sm-12 col-md-6">
              <div class="job-info">
                <img src="<?php echo e(url()->asset('public/images/newdesign/Rectangle.png') . getPictureVersion()); ?>" class="mx-auto" alt="Avatar"/>
                <p>
                  For job seekers, you will register your account and build your
                                                                    curriculum vitae. From there, you can start browsing the jobs
                                                                    currently posted. When searching the Virtual Worker's job board,
                                                                    you can search by:
                </p>
                <ul>
                  <li>Recently Posted Jobs</li>
                  <li>Job Type.</li>
                  <li>Offered Salary</li>
                  <li>Job Category</li>
                  <li>Industry and more</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="improve-business">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-12 col-md-6">
              <img src="<?php echo e(url()->asset('public/images/newdesign/AdobeStock_210940773-[Converted] 1.png') . getPictureVersion()); ?>" alt="Book Image">
            </div>
            <div class="col-sm-12 col-md-6">
              <h1>5 Ways To IMPROVE YOUR BUSINESS USING VIRTUAL WORKERS</h1>
              <div class="free-info">Free Report</div>
              <p>We have generated over $1.33 billion in sales with the 5 unbelievably powerful strategies outlined in this free report. Download it now before this page comes down or your competitors get their hands on it.</p>

              <div class="container-fluid">
                <div class="row">
                  <div class="col-sm-6">
                    <input type="text" class="form-control">
                  </div>
                  <div class="col-sm-6">
                    <input type="text" class="form-control">
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6">
                    <input type="text" class="form-control">
                  </div>
                  <div class="col-sm-6">
                    <input type="text" class="form-control">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="online-home">
        <h1>Online Home-Based Jobs for 2020 and Beyond</h1>
        <p>
          Whether you are looking for an online home-based job or to hire new talent for your company, our virtual assistant agency is here to help.
                    Virtual Workers is a community filled with like-minded individuals who understand times are changing, and the job market is unlikely to return to "business as usual." Let us help you find the right candidate for your open position or the right work from home job that suits your skill set.
        </p>
      </div>
    </div>
		
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/virtualworkers.app/resources/views/home/index.blade.php ENDPATH**/ ?>