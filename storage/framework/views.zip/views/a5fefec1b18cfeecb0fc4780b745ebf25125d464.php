
<td>
	<?php
	    echo $entry->{$column['function_name']}();
    ?>
</td><?php /**PATH /var/www/html/virtualworkers.app/resources/views/vendor/admin/panel/columns/model_function.blade.php ENDPATH**/ ?>