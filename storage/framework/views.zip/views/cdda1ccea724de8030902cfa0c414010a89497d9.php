<?php $__env->startSection('content'); ?>
<style>
.card.shadow.mb-4 {
    margin-bottom: 79% !important;
}
</style>
<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

    <!-- Main Content -->
    <div id="content">
        <!-- Begin Page Content -->
        <div class="container-fluid py-4">
            <div class="row mb-4">
                <div class="col-md-3 col-sm-12">
                    <h1 class="h3 mb-0 page-title">Administration</h1>
                </div>
                <div class="offset-md-6 col-md-3 col-sm-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Administration</li>
                        </ol>
                    </nav>
                </div>
            </div>
            <!-- Page Heading -->
            <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php if(isset($errors) && $errors->any()): ?>
            <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h5><strong><?php echo e(t('oops_an_error_has_occurred')); ?></strong></h5>
                <ul class="list list-check">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

            <div class="row">

                <!-- Area Chart -->
                <div class="col-xl-6 col-lg-6">
                    <div class="card shadow account-detail-form">
                        <div class="card-header py-3 align-items-center justify-content-between">
                            <h6 class="page-sub-title account-detail"> <?php echo e(t('Account Details')); ?></h6>
                            <p class="last-login-detail">
                                <?php echo e(t('You last logged in at')); ?>:
                                <?php echo e(\App\Helpers\Date::format($user->last_login_at, 'datetime')); ?>

                            </p>
                        </div>
                        <form name="details" class="form-horizontal" role="form" method="POST"
                            action="<?php echo e(url('account')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <input name="_method" type="hidden" value="PUT">
                            <input name="panel" type="hidden" value="user">
                            
                            <?php $userTypeIdError = (isset($errors) && $errors->has('user_type_id')) ? ' is-invalid' : ''; ?>
                            <div class="card-body">
                                
                                <?php $nameError = (isset($errors) && $errors->has('name')) ? ' is-invalid' : ''; ?>
                                <div class="form-group row required">
                                    <label for="inputPassword" class="col-sm-2 col-form-label"><?php echo e(t('Name')); ?></label>
                                    <div class="col-sm-9">
                                        <input name="name" type="text" class="form-control<?php echo e($nameError); ?>"
                                            placeholder="" value="<?php echo e(old('name', $user->name)); ?>">
                                    </div>
                                </div>
                                
                                <?php $usernameError = (isset($errors) && $errors->has('username')) ? ' is-invalid' : ''; ?>
                                <div class="form-group row required">
                                    <label for="inputPassword"
                                        class="col-sm-2 col-form-label"><?php echo e(t('Username')); ?></label>
                                    <div class="col-sm-9">
                                        <input id="username" name="username" type="text"
                                            class="form-control<?php echo e($usernameError); ?>" placeholder="<?php echo e(t('Username')); ?>"
                                            value="<?php echo e(old('username', $user->email)); ?>" readonly>
                                    </div>
                                </div>
                                
                                <?php $emailError = (isset($errors) && $errors->has('email')) ? ' is-invalid' : ''; ?>
                                <div class="form-group row required">
                                    <label for="inputPassword" class="col-sm-2 col-form-label"><?php echo e(t('email')); ?>

                                        <label class="label label-danger" style="color: red;">*</label>
                                    </label>
                                    <div class="col-sm-9">
                                        <input id="email" name="email" type="email"
                                            class="form-control<?php echo e($emailError); ?>" placeholder="<?php echo e(t('email')); ?>"
                                            value="<?php echo e(old('email', $user->email)); ?>" readonly>
                                    </div>
                                </div>
                                
                                <?php $phoneError = (isset($errors) && $errors->has('phone')) ? ' is-invalid' : ''; ?>
                                <div class="form-group row required">
                                    <label for="inputPassword" class="col-sm-2 col-form-label"><?php echo e(t('phone')); ?></label>
                                    <div class="col-sm-9">
                                        <input id="phone" name="phone" type="text" class="form-control<?php echo e($phoneError); ?>"
                                            placeholder="<?php echo e((!isEnabledField('email')) ? t('Mobile Phone Number') : t('phone_number')); ?>"
                                            value="<?php echo e(phoneFormat(old('phone', $user->phone), old('country_code', $user->country_code))); ?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-4 offset-sm-2 terminate-link-section">
                                        <a class="terminate-account-link" href="#" data-toggle="modal"
                                            data-target="#terminateModal"
                                            href="javascript:;"><?php echo e(t('Terminate Account')); ?></a>
                                    </div>
                                    <div class="col-sm-5 btn-section update-btn-section">
                                        <button type="submit" class="profile-update-btn"><?php echo e(t('Update')); ?></button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-6">
                    <div class="card shadow update-password-form">
                        <div class="card-header py-3 align-items-center justify-content-between">
                            <h6 class="page-sub-title account-detail">Update Password</h6>
                        </div>
                        <form name="settings" class="form-horizontal" role="form" method="POST"
                            action="<?php echo e(url('account/settings')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <input name="_method" type="hidden" value="PUT">
                            <input name="panel" type="hidden" value="settings">
                            <input name="gender_id" type="hidden" value="<?php echo e($user->gender_id); ?>">
                            <input name="name" type="hidden" value="<?php echo e($user->name); ?>">
                            <input name="phone" type="hidden" value="<?php echo e($user->phone); ?>">
                            <input name="email" type="hidden" value="<?php echo e($user->email); ?>">
                            <div class="card-body">
                                
                                <?php $passwordError = (isset($errors) && $errors->has('old_password')) ? ' is-invalid' : ''; ?>
                                <div class="form-group row required">
                                    <label for="inputPassword"
                                        class="col-sm-3 col-form-label"><?php echo e(t('Old Password')); ?></label>
                                    <div class="col-sm-8">
                                        <input name="old_password" type="password"
                                            class="form-control<?php echo e($passwordError); ?>" id="old_password"
                                            placeholder="<?php echo e(t('Old Password')); ?>">
                                    </div>
                                </div>
                                
                                <?php $passwordError = (isset($errors) && $errors->has('password')) ? ' is-invalid' : ''; ?>
                                <div class="form-group row required">
                                    <label for="inputPassword"
                                        class="col-sm-3 col-form-label"><?php echo e(t('New Password')); ?></label>
                                    <div class="col-sm-8">
                                        <input id="password" name="password" type="password"
                                            class="form-control<?php echo e($passwordError); ?>"
                                            placeholder="<?php echo e(t('New Password')); ?>">
                                    </div>
                                </div>
                                
                                <?php $passwordError = (isset($errors) && $errors->has('password_confirmation')) ? ' is-invalid' : ''; ?>
                                <div
                                    class="form-group row <?php echo (isset($errors) && $errors->has('password_confirmation')) ? ' is-invalid' : ''; ?>">
                                    <label for="inputPassword"
                                        class="col-sm-3 col-form-label"><?php echo e(t('Confirm Password')); ?></label>
                                    <div class="col-sm-8">
                                        <input id="password_confirmation" name="password_confirmation" type="password"
                                            class="form-control<?php echo e($passwordError); ?>"
                                            placeholder="<?php echo e(t('Confirm Password')); ?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-3 offset-sm-3 lost-password-section">
                                        <!-- <a class="terminate-account-link" data-toggle="modal"
                                            data-target="#lostPassModal"
                                            href="javascript:;"><?php echo e(t('Lost Password')); ?></a> -->
                                        <a class="terminate-account-link"
                                            href="<?php echo e(url('password/reset')); ?>"><?php echo e(t('Lost Password')); ?></a>
                                    </div>
                                    <div class="col-sm-5 btn-section update-btn-section">
                                        <button type="submit" class="profile-update-btn"><?php echo e(t('Update')); ?></button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- End of Main Content -->
    <!-- Terminate Account Modal-->
    <div class="modal fade" id="terminateModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog terminated-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <p class="terminate-account-text mt-4">
                        Please confirm you would like to terminate your account.
                    </p>
                    <div class="row mb-4">
                        <div class="col-md-7 text-right cancel-termination">
                            <button class="cancel-termination-btn" data-dismiss="modal">Cancel Termination</button>
                        </div>
                        <div class="col-md-5 text-left popup-terminate ">
                            <form action="<?php echo e(url('account/close')); ?>" method="post">
                                <?php echo csrf_field(); ?>

                                <button class="terminate-account-link" type="submit">
                                    <?php echo e(t('Terminate Account')); ?></button>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- Update password Modal-->
    <div class="modal fade" id="lostPassModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Forgot Password</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form class="" action="" id="forgot-password" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Enter Registered Email address</label>
                            <input type="email" class="form-control" name="login" id="forgotpassword_email"
                                aria-describedby="emailHelp" placeholder="Enter email">
                        </div>
                        <button class="forgot-password-btn" id="submit-forgotpassword" type="button"> Send</button>
                        <button type="button" class="profile-update-btn" data-dismiss="modal">Cancel</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.workers-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/virtualworkers.app/resources/views/account/edit.blade.php ENDPATH**/ ?>