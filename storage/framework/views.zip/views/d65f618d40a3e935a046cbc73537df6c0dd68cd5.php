<?php if($xPanel->hasAccess('show')): ?>
	<a href="<?php echo e(url($xPanel->route.'/'.$entry->getKey())); ?>" class="btn btn-xs btn-secondary"><i class="fa fa-eye"></i> <?php echo e(trans('admin.preview')); ?></a>
<?php endif; ?><?php /**PATH /var/www/html/virtualworkers.app/resources/views/vendor/admin/panel/buttons/preview.blade.php ENDPATH**/ ?>