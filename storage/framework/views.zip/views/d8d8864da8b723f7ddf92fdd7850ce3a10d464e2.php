<?php $__env->startSection('title', t('Internal Server Error')); ?>

<?php $__env->startSection('search'); ?>
	##parent-placeholder-3559d7accf00360971961ca18989adc0614089c0##
	<?php echo $__env->make('errors.layouts.inc.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('common.spacer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="main-container inner-page">
		<div class="container">
			<div class="section-content">
				<div class="row">

					<div class="col-md-12 page-content">
						
						<div class="error-page mt-5 mb-5 ml-0 mr-0 pt-5">
							<h1 class="headline text-center" style="font-size: 180px;">500</h1>
							<div class="text-center m-l-0 mt-5">
								<h3 class="m-t-0 color-danger">
									<i class="fas fa-exclamation-triangle"></i> <?php echo e(t('Internal Server Error')); ?>

								</h3>
								<p>
									<?php
									$defaultErrorMessage = t('An internal server error has occurred');
									
									if (isset($exception)) {
										echo ($exception->getMessage()) ? $exception->getMessage() : $defaultErrorMessage;
									} else {
										echo $defaultErrorMessage;
									}
									?>
								</p>
							</div>
						</div>

					</div>

				</div>
			</div>

            <?php
				$requirements = [];
				$requiredPhpVersion = _getComposerRequiredPhpVersion();
				if (!version_compare(PHP_VERSION, $requiredPhpVersion, '>=')) {
					$requirements[] = 'PHP ' . $requiredPhpVersion . ' or higher is required.';
				}
				if (!extension_loaded('openssl')) {
					$requirements[] = 'OpenSSL PHP Extension is required.';
				}
				if (!extension_loaded('mbstring')) {
					$requirements[] = 'Mbstring PHP Extension is required.';
				}
				if (!extension_loaded('pdo')) {
					$requirements[] = 'PDO PHP Extension is required.';
				}
				if (!extension_loaded('tokenizer')) {
					$requirements[] = 'Tokenizer PHP Extension is required.';
				}
				if (!extension_loaded('xml')) {
					$requirements[] = 'XML PHP Extension is required.';
				}
				if (!extension_loaded('fileinfo')) {
					$requirements[] = 'PHP Fileinfo Extension is required.';
				}
				if (!(extension_loaded('gd') && function_exists('gd_info'))) {
					$requirements[] = 'PHP GD Library is required.';
				}
            ?>
			<?php if(isset($requirements)): ?>
			<div class="row">
				<div class="col-md-12">
					<ul class="installation">
						<?php $__currentLoopData = $requirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li>
								<i class="icon-cancel text-danger"></i>
								<h5 class="title-5">
									Error #<?php echo e($key); ?>

								</h5>
								<p>
									<?php echo e($item); ?>

								</p>
							</li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
				</div>
			</div>
			<?php endif; ?>
			
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/virtualworkers.app/resources/views/errors/500.blade.php ENDPATH**/ ?>