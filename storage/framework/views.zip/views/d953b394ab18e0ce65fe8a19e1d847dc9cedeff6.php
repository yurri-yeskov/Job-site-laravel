
<td>
	<?php
		if ($entry->{$column['entity']}()->getResults()) {
	    	echo $entry->{$column['entity']}()->getResults()->{$column['attribute']};
	    }
	?>
</td><?php /**PATH /var/www/html/virtualworkers.app/resources/views/vendor/admin/panel/columns/select.blade.php ENDPATH**/ ?>