
<td>
    <?php
        $results = $entry->{$column['entity']}()->getResults();

        if ($results && $results->count()) {
            $results_array = $results->pluck($column['attribute'], 'id');
            echo implode(', ', $results_array->toArray());
        } else {
            echo '-';
        }
    ?>
</td><?php /**PATH /var/www/html/virtualworkers.app/resources/views/vendor/admin/panel/columns/select_multiple.blade.php ENDPATH**/ ?>